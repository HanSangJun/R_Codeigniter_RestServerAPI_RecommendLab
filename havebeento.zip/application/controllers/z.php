<?php
exec("Rscript /home/rstudio/training.R");
?>
