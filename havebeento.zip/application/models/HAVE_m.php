<?php defined('BASEPATH') OR exit('No direct script access allowed');

class HAVE_m extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function login($name, $password)
    {
    	$query = $this->db->query("SELECT * FROM member WHERE name='" . $name . "' and password='" . $password . "'");

    	return $query->row_array();
    }

    public function get_rating_all()
    {
        $query = $this->db->query("SELECT * FROM rating");

        return $query->result_array();
    }

    public function get_rating_by($member_id)
    {
		$query = $this->db->query("SELECT travel_id, rating FROM rating WHERE member_id='" . $member_id . "'");

		return $query->result_array();
    }

    public function get_unique_member()
    {
        $query = $this->db->query("SELECT member_id FROM member");

        return $query->result_array();
    }

    public function get_unique_travel()
    {
        $query = $this->db->query("SELECT travel_id FROM travel_list");

        return $query->result_array();
    }

    public function get_travel_all()
    {
        $query = $this->db->query("SELECT * FROM travel_list NATURAL JOIN travel_site NATURAL LEFT JOIN detail_info");

        return $query->result_array();
    }

    public function get_member_travel_by($member_id)
    {
        $query = $this->db->query("SELECT * FROM travel_list NATURAL JOIN travel_site WHERE travel_id IN (SELECT distinct(travel_id) FROM rating WHERE member_id = '" . $member_id . "')");

        return $query->result_array();
    }

    public function get_search_travel_by($nation_name, $city_name, $dept_date, $price_min, $departure)
    {
        //$query = $this->db->query("SELECT * FROM travel_list NATURAL JOIN travel_site NATURAL LEFT JOIN detail_info");
        $this->db->select('*');
        $this->db->from('travel_list');
        $this->db->join('travel_site', 'travel_list.city_code = travel_site.city_code');
        $this->db->join('detail_info', 'travel_list.travel_id = detail_info.travel_id');

         if(empty($nation_name))
        {
             $this->db->where('nation_name !=', NULL);
        }
        else
        {
             $this->db->where('nation_name', $nation_name);
        }

        if(empty($city_name))
        {
             $this->db->where('city_name !=', NULL);
        }
        else
        {
             $this->db->where('city_name', $city_name);
        }

        if(empty($dept_date))
        {
             $this->db->where('dept_date !=', NULL);
        }
        else
        {
             $this->db->where('dept_date', $dept_date);
        }

        if(empty($departure))
        {
             $this->db->where('departure !=', NULL);
        }
        else
        {
             $this->db->where('departure', $departure);
        }

         if(empty($price_min))
        {
             $this->db->where('price !=', NULL);
        }
        else
        {
             $this->db->where('price <=', $price_min);
        }

        $query = $this->db->get();

        return $query->result_array();
    }

    public function get_travel_by_array($travel_id_array)
    {
        $id = implode("','", $travel_id_array);
        $query = $this->db->query("SELECT * FROM travel_list NATURAL JOIN travel_site WHERE travel_id IN ('" . $id . "') ORDER BY FIELD(travel_id,'" . $id . "')");

        return $query->result_array();
    }

    public function insert_rating_travel($member_id, $travel_id, $rating)
    {
        $query = $this->db->query("INSERT INTO rating(member_id, travel_id, rating) VALUES ('" . $member_id . "', '" . $travel_id . "', '" . $rating . "')");
    }

    public function get_review_by($travel_id)
    {
        $query = $this->db->query("SELECT name, content, date FROM review NATURAL JOIN member WHERE travel_id = '" . $travel_id . "'");

        return $query->result_array();
    }

    public function insert_review_by($member_id, $travel_id, $content)
    {
        $date = date("Y-m-d H:i:s");
        $query = $this->db->query("INSERT INTO review(member_id, travel_id, content, date) VALUES ('" . $member_id . "', '" . $travel_id . "', '" . $content . "', '" . $date . "')");
    }

    public function get_except_member_travel_by($member_id)
    {
        $query = $this->db->query("SELECT * FROM travel_list NATURAL JOIN travel_site WHERE travel_id NOT IN (SELECT distinct(travel_id) FROM rating WHERE member_id = '" . $member_id . "')");

        return $query->result_array();
    }
}
